#include "UBCalculator.h"
#include <sstream>

const std::map<char, char> UBCalculator::delimMatch = UBCalculator::createDelimMatch();
 std::map<char, int> UBCalculator::precedenceMap = UBCalculator::createPrecedenceMap();
 const std::string UBCalculator::openDelims = "([{";
 const std::string UBCalculator::closeDelims = ")]}";

// Get input from user 
void UBCalculator::setLine(std::string str)
{
   return;
}
