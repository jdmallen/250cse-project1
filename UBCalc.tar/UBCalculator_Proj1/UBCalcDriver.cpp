// UBCalcDriver.cpp : a simple driver for the the Lexer class
#include <iostream>
#include <vector>
#include <cstdlib>
#include "UBCalculator.h"
#include "Lexer.h"

using namespace std;

int main() {
	UBCalculator calculator;
	Lexer lexer;
	Token tok;
	string line;
    while (cin) {
        cout << ">>> ";
		getline(cin, line);
		if ((line == "quit") || (line == "exit"))
		{
			exit(0);
		}
		if (line == "")
		{
			continue;
		}
		try{
			calculator.setLine(line);
		}
		catch (runtime_error &e) {
			error_return(e.what());
		}

    }
    return 0;
}
